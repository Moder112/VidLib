Welcum to the epic vildill loader or whatever I'll call it, anyway this program is epic
you can download all your favorite videos and it's VIRUS FREE!!!
your mom won't take your gamer pc access f or downloading naked ladies!

her'es hte syn tax

Vidlib.exe [Arguments] <Link to Text file/Channel/Video>

Arrrrrgument list:
-HQ - downlod in 720penis,get it funne!!!
-get-thumb - if you wanna downlod the toenail for the naked lady vides !!!!
-save-metadata - Sve file in the funny minecraft language format, shit I forgot mineckraft wasn't a thing in 2008 shitfuyckgucksguckg
-no-video - doesn't download any video!!! you get nothing,trorlorlrolrlol

-path *IS MANDATORY(imporent)*
follow up wthith the path to the folder wher youwant to save !

it also comes with additonal envirorment values! for fre1!!

@[url] - video id
@[file] - cdn server file id
@[hd] - Hd video status *UNUSED*
@[title] - video title
@[category] - Video Category
@[uploaded_by] - uploader
@[uploaded_on] - upload date
@[ext] - Extension //MANDATORY

here's a valid location for example, so your dad won
t get mad at you end get drunk
"C:\Users\sex\Documents\Vidlii\@[uploaded_by]\@[url]\@[title]@[ext]"

put TEH STUFF YOU WANNA DOWANLOD IN Vidliilist.txt !!!!